package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class GlennFox_Playlist {
    
	public LinkedList<PlayableSong> StudentPlaylist(){
	
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	//add Foo Fighters
	ArrayList<Song> fooFightersTracks = new ArrayList<Song>();
    FooFighters fooFightersBand = new FooFighters();
	
    fooFightersTracks = fooFightersBand.getFooFightersSongs();
	
	playlist.add(fooFightersTracks.get(0));
	playlist.add(fooFightersTracks.get(1));
	playlist.add(fooFightersTracks.get(2));
	
	//add Rush
	ArrayList<Song> rushTracks = new ArrayList<Song>();
	Rush rushBand = new Rush();
	
	rushTracks = rushBand.getRushSongs();
	
	playlist.add(rushTracks.get(0));
			
	//add Beatles
	ArrayList<Song> beatlesTracks = new ArrayList<Song>();
    TheBeatles theBeatlesBand = new TheBeatles();
	
    beatlesTracks = theBeatlesBand.getBeatlesSongs();
	
	playlist.add(beatlesTracks.get(2));

			
	//add Kool and the Gang, other students addition
	ArrayList<Song> koolAndTheGangTracks = new ArrayList<Song>();
	KoolAndTheGang koolAndTheGangBand = new KoolAndTheGang();
	
	koolAndTheGangTracks = koolAndTheGangBand.getKoolAndTheGangSongs();
	
	playlist.add(koolAndTheGangTracks.get(0));
	
	
    return playlist;
	}
}
