//Added by Erik Tomchek on 10/02/21
package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class ErikTomchek_Playlist {
    
	public LinkedList<PlayableSong> StudentPlaylist(){
	
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	//Bob Seger Below
	ArrayList<Song> bobSegerTracks = new ArrayList<Song>();
    BobSeger bobSegerBand = new BobSeger();
    bobSegerTracks = bobSegerBand.getBobSegerSongs();
	
	playlist.add(bobSegerTracks.get(0));
	playlist.add(bobSegerTracks.get(1));
	playlist.add(bobSegerTracks.get(2));
	playlist.add(bobSegerTracks.get(3));
	
	
	
	//HarryChapin Below
    HarryChapin harryChapinBand = new HarryChapin();
	ArrayList<Song> harryChapinTracks = new ArrayList<Song>();
	harryChapinTracks = harryChapinBand.getHarryChapinSongs();
	
	playlist.add(harryChapinTracks.get(0));
	
// FooFighters Below (another student's added song)
    FooFighters fooFightersBand = new FooFighters();
	ArrayList<Song> fooFightersTracks = new ArrayList<Song>();
	fooFightersTracks = fooFightersBand.getFooFightersSongs();
	
	playlist.add(fooFightersTracks.get(0));

	
    return playlist;
	}
}
