package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class XhefriToro_Playlist {
    
	public LinkedList<PlayableSong> StudentPlaylist(){
	
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	//Guns N Roses
	ArrayList<Song> gunsNRosesTracks = new ArrayList<Song>();
	GunsNRoses gunsNRoses = new GunsNRoses();
    gunsNRosesTracks = gunsNRoses.getGunsNRosesSongs();
	
	playlist.add(gunsNRosesTracks.get(0));
	playlist.add(gunsNRosesTracks.get(1));
	playlist.add(gunsNRosesTracks.get(2));
	
	
	
	//LedZeppelin
	LedZeppelin ledZeppelin = new LedZeppelin();
	ArrayList<Song> ledZeppelinTracks = new ArrayList<Song>();
	ledZeppelinTracks = ledZeppelin.getLedZeppelinSongs();
	
	playlist.add(ledZeppelinTracks.get(1));
	
	// The Weekend Tracks from Jeremy Williams (another student's added song)
	ArrayList<Song> theWeekndTracks = new ArrayList<Song>();
	TheWeeknd theWeeknd = new TheWeeknd();
	theWeekndTracks = theWeeknd.getTheWeekndSongs();
	
	playlist.add(theWeekndTracks.get(0));
	playlist.add(theWeekndTracks.get(2));

	
    return playlist;
	}
}
