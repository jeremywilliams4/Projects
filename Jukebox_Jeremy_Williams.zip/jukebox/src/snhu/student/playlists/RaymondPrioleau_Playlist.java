package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class RaymondPrioleau_Playlist {
	/* added for module 6 requirements
	 * songs from Kool and the gang, The Isley Brothers, and The Weekend
	 */
    
	public LinkedList<PlayableSong> StudentPlaylist(){
	
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	// Add The Isley Brothers
	ArrayList<Song> isleyTracks = new ArrayList<Song>();
	TheIsleyBrothers theIsleyBrothers = new TheIsleyBrothers();
	isleyTracks = theIsleyBrothers.getIsleyBrothersSongs();
	
	playlist.add(isleyTracks.get(0));
	playlist.add(isleyTracks.get(1));
	playlist.add(isleyTracks.get(2));	
	playlist.add(isleyTracks.get(3));
	
	// Add Kool and the Gang
	ArrayList<Song> koolTracks = new ArrayList<Song>();
	KoolAndTheGang koolAndTheGang = new KoolAndTheGang();
	koolTracks = koolAndTheGang.getKoolAndTheGangSongs();
	
	playlist.add(koolTracks.get(0));
	playlist.add(koolTracks.get(1));
	
	// Added The weekend 
	ArrayList<Song> theWeekndTracks = new ArrayList<Song>();
	TheWeeknd theWeeknd = new TheWeeknd();
	theWeekndTracks = theWeeknd.getTheWeekndSongs();
	
	playlist.add(theWeekndTracks.get(0));
	playlist.add(theWeekndTracks.get(1));
	
    return playlist;
	}
}
