package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class JeremyWilliams_Playlist {
	/* added for module 6 requirements
	 * songs from Phil Collins and The Weeknd
	 */
    
	public LinkedList<PlayableSong> StudentPlaylist(){
	
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	ArrayList<Song> philCollinsTracks = new ArrayList<Song>();
	PhilCollins philCollins = new PhilCollins();
	philCollinsTracks = philCollins.getPhilCollinsSongs();
	
	playlist.add(philCollinsTracks.get(0));
	playlist.add(philCollinsTracks.get(1));
	playlist.add(philCollinsTracks.get(2));	

	ArrayList<Song> theWeekndTracks = new ArrayList<Song>();
	TheWeeknd theWeeknd = new TheWeeknd();
	theWeekndTracks = theWeeknd.getTheWeekndSongs();
	
	playlist.add(theWeekndTracks.get(0));
	playlist.add(theWeekndTracks.get(1));
	playlist.add(theWeekndTracks.get(2));


	
    return playlist;
	}
}