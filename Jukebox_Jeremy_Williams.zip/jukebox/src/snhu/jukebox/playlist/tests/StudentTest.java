package snhu.jukebox.playlist.tests;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import snhu.jukebox.playlist.Student;
import snhu.jukebox.playlist.StudentList;
import snhu.student.playlists.*;


public class StudentTest {

	//Test the list of student names and ensure we get back the name value we expect at the correct/specific point in the list
	@Test
	public void testGetStudentNameList1() {
		List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
		StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("TestStudent1Name", studentNames.get(0));		//test case for pass/fail. We expect the first name to be TestStudent1Name. Remember arrays start their count at 0 not 1.
	}
	
	@Test
	public void testGetStudentNameList2() {
		List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
		StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("TestStudent2Name", studentNames.get(1));		//test case to see if the second value contains the name we expect
	}
	
	//Module 5 - Add your unit test case here to check for your name after you have added it to the StudentList
	
	@Test
	public void testGetPhilipEnkema() {
		List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
		StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Philip Enkema", studentNames.get(3));			//test case to see if the fourth value contains the name we expect
	}
	
	@Test
	public void testGetGlennFox() {
		List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
		StudentList studentList = new StudentList();			    //instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames(); 				//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Glenn Fox", studentNames.get(2));				//test case to see if the third value contains the name we expect
		
	}
	
	@Test
	public void testGetRaymondPrioleau() {
			List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
			StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties
			studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object
			assertEquals("Raymond Prioleau", studentNames.get(4));			//test case to see if the fifth value contains the name we expect
	}
	
	@Test
	public void testGetNicholasEls() {
			List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
			StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties
			studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object
			assertEquals("Nicholas Els", studentNames.get(5));			//test case to see if the sixth value contains the name we expect
	}
	
	@Test

	public void testGetErikTomchek() {
		List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
		StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Erik Tomchek", studentNames.get(6));			//test case to see if the seventh value contains the name we expect
	}
	
	@Test

	public void testGetJeremyWilliams() {
		List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
		StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Jeremy Williams", studentNames.get(7));		//test case to see if the fourth value contains the name we expect
	}
	@Test
	public void testGetMarkEllis() {
			List<String> studentNames = new ArrayList<String>();		//create variable for student list of names updated by Mark 2021-09-30
			StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties updated by Mark 2021-09-30
			studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object updated by Mark 2021-09-30
			assertEquals("Mark Ellis", studentNames.get(8));			//test case to see if the sixth value contains the name we expect updated by Mark 2021-09-30
	}

	@Test
	public void testGetPaulSchwartz() {
		List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
		StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Paul Schwartz", studentNames.get(9));		//test case number changed to last test number + 1, Erik Tomchek was number 6.  So i am #7
	}
	
	@Test
	public void testGetXheriToro() {
		List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
		StudentList studentList = new StudentList();			    //instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames(); 				//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Xhefri Toro", studentNames.get(studentNames.indexOf("Xhefri Toro")));   //test case to see if my name is part of the list and get its index dynamically
		
	}
	
	public void testGetKennethPosley() {
		List<String> studentNames = new ArrayList<String>();		//create variable for student list of names
		StudentList studentList = new StudentList();				//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();				//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Kenneth Posley", studentNames.get(8));		//test case for pass/fail. We expect the first name to be TestStudent1Name. Remember arrays start their count at 0 not 1.
	}
	//Module 6 Test Case Area
	//Test each student profile to ensure it can be retrieved and accessed
	@Test
	public void testGetStudent1Profile() {
		TestStudent1_Playlist testStudent1Playlist = new TestStudent1_Playlist();						//instantiating the variable for a specific student
		Student TestStudent1 = new Student("TestStudent1", testStudent1Playlist.StudentPlaylist());		//creating populated student object
		assertEquals("TestStudent1", TestStudent1.getName());											//test case pass/fail line - did the name match what you expected?
	}
	
	@Test
	public void testGetStudent2Profile() {
		TestStudent2_Playlist testStudent2Playlist = new TestStudent2_Playlist();
		Student TestStudent2 = new Student("TestStudent2", testStudent2Playlist.StudentPlaylist());
		assertEquals("TestStudent2", TestStudent2.getName());
	}
	
	//Module 6 - Add your unit test case here to check for your profile after you have added it to the StudentList
	
	@Test
	public void testGetPhilipEnkemaProfile() {     // added instructor profile test
		PhilipEnkema_Playlist PhilipEnkema_Playlist = new PhilipEnkema_Playlist();
		Student PhilipEnkema = new Student("Philip Enkema", PhilipEnkema_Playlist.StudentPlaylist());
		assertEquals("Philip Enkema", PhilipEnkema.getName());
	}
	
	//Added By Erik Tomchek 10/02/21
	public void testGetErikTomchekProfile() {     // added my profile test
		ErikTomchek_Playlist ErikTomchek_Playlist = new ErikTomchek_Playlist();
		Student ErikTomchek = new Student("Erik Tomchek", ErikTomchek_Playlist.StudentPlaylist());
		assertEquals("Erik Tomchek", ErikTomchek.getName());
	}
	

	//Added by Jeremy Williams
	@Test
	public void testGetJeremyWilliamsProfile() {     // added my profile test
		JeremyWilliams_Playlist JeremyWilliams_Playlist = new JeremyWilliams_Playlist();
		Student JeremyWilliams = new Student("Jeremy Williams", JeremyWilliams_Playlist.StudentPlaylist());
		assertEquals("Jeremy Williams", JeremyWilliams.getName());
	}

	@Test
	public void testGetGlennFoxProfile() { // added by g.fox
		GlennFox_Playlist GlennFox_Playlist = new GlennFox_Playlist();
		Student GlennFox = new Student("Glenn Fox", GlennFox_Playlist.StudentPlaylist());
		assertEquals("Glenn Fox", GlennFox.getName());
	}
	@Test
	public void testGetXhefriToroProfile() {
		XhefriToro_Playlist xhefriToro_Playlist = new XhefriToro_Playlist();
		Student xhefriToro = new Student("Xhefri Toro", xhefriToro_Playlist.StudentPlaylist());
		assertEquals("Xhefri Toro", xhefriToro.getName());
		
	}
	
	@SuppressWarnings("unused")
	@Test
	public void testGetKennethPosleyProfile() {
		KennethPosley_Playlist KennetPosley_Playlist = new KennethPosley_Playlist();	
		Student KennethPosley = new Student("KennethPosley", KennethPosley_Playlist.StudentPlaylist());		
		assertEquals("Kenneth Posley", KennethPosley.getName());		
	}
	
	@Test
	public void testGetRaymondPrioleauProfile() {     // added RaymondPrioleau profile test
		RaymondPrioleau_Playlist RaymondPrioleau_Playlist = new RaymondPrioleau_Playlist();
		Student RaymondPrioleau = new Student("Raymond Prioleau", RaymondPrioleau_Playlist.StudentPlaylist());
		assertEquals("Raymond Prioleau", RaymondPrioleau.getName());
	}

}
