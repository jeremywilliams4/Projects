package snhu.jukebox.playlist.tests;

import java.util.LinkedList;

import snhu.jukebox.playlist.PlayableSong;

public class KennethPosley_Playlist {

	public static LinkedList<PlayableSong> StudentPlaylist() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
