package snhu.jukebox.playlist.tests;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.Test;
import music.artist.*;
import snhu.jukebox.playlist.Song;

public class JukeboxTest {

	@Test
	public void testGetBeatlesAlbumSize() throws NoSuchFieldException, SecurityException {
		 TheBeatles theBeatlesBand = new TheBeatles();
		 ArrayList<Song> beatlesTracks = new ArrayList<Song>();
		 beatlesTracks = theBeatlesBand.getBeatlesSongs();
		 assertEquals(3, beatlesTracks.size());
	}
	
	@Test
	public void testGetImagineDragonsAlbumSize() throws NoSuchFieldException, SecurityException {
		 ImagineDragons imagineDragons = new ImagineDragons();
		 ArrayList<Song> imagineDragonsTracks = new ArrayList<Song>();
		 imagineDragonsTracks = imagineDragons.getImagineDragonsSongs();
		 assertEquals(3, imagineDragonsTracks.size());
	}
	
	@Test
	public void testGetAdelesAlbumSize() throws NoSuchFieldException, SecurityException {
		 Adele adele = new Adele();
		 ArrayList<Song> adelesTracks = new ArrayList<Song>();
		 adelesTracks = adele.getAdelesSongs();
		 assertEquals(3, adelesTracks.size());
	}

	@Test     // added by p.enkema
	public void testGetBurtBacharachAlbumSize() throws NoSuchFieldException, SecurityException {
		 BurtBacharach burtBacharach = new BurtBacharach();
		 ArrayList<Song> burtBacharachTracks = new ArrayList<Song>();
		 burtBacharachTracks = burtBacharach.getBurtBacharachSongs();
		 assertEquals(3, burtBacharachTracks.size());
	}

	@Test     // added by p.enkema
	public void testGetHerbAlpertAlbumSize() throws NoSuchFieldException, SecurityException {
		 HerbAlpert herbAlpert = new HerbAlpert();
		 ArrayList<Song> herbAlpertTracks = new ArrayList<Song>();
		 herbAlpertTracks = herbAlpert.getHerbAlpertSongs();
		 assertEquals(2, herbAlpertTracks.size());
	}
	
	@Test     // added by g.fox
	public void testFooFightersAlbumSize() throws NoSuchFieldException, SecurityException {
		 FooFighters fooFighters = new FooFighters();
		 ArrayList<Song> fooFightersTracks = new ArrayList<Song>();
		 fooFightersTracks = fooFighters.getFooFightersSongs();
		 assertEquals(3, fooFightersTracks.size());
	}
	
	@Test	// added by g.fox
	public void testRushAlbumSize() throws NoSuchFieldException, SecurityException {
		Rush rush = new Rush();
		ArrayList<Song> rushTracks = new ArrayList<Song>();
		rushTracks = rush.getRushSongs();
		assertEquals(1, rushTracks.size());
		
	}
	
	@Test     // added by nicholas_els
	public void testCorvusCoraxAlbumSize() throws NoSuchFieldException, SecurityException {
		 CorvusCorax corvusCorax = new CorvusCorax();
		 ArrayList<Song> corvusCoraxTracks = new ArrayList<Song>();
		 corvusCoraxTracks = corvusCorax.getCorvusCoraxSongs();
		 assertEquals(3, corvusCoraxTracks.size());
	}
	
	@Test	// added by nicholas_els
	public void testBrothersOfMetalAlbumSize() throws NoSuchFieldException, SecurityException {
		BrothersOfMetal brothersOfMetal = new BrothersOfMetal();
		ArrayList<Song> brothersOfMetalTracks = new ArrayList<Song>();
		brothersOfMetalTracks = brothersOfMetal.getBrothersOfMetalSongs();
		assertEquals(2, brothersOfMetalTracks.size());
		
	}
	
	@Test	// added by Erik Tomchek  
	public void testBobSegerAlbumSize() throws NoSuchFieldException, SecurityException {
		BobSeger bobSeger = new BobSeger();
		ArrayList<Song> bobSegerTracks = new ArrayList<Song>();
		bobSegerTracks = bobSeger.getBobSegerSongs();
		assertEquals(4, bobSegerTracks.size());
		
	}
	
	@Test	// added by Erik Tomchek 
	public void testHarryChapinrAlbumSize() throws NoSuchFieldException, SecurityException {
		HarryChapin harryChapin = new HarryChapin();
		ArrayList<Song> harryChapinTracks = new ArrayList<Song>();
		harryChapinTracks = harryChapin.getHarryChapinSongs();
		assertEquals(1, harryChapinTracks.size());
		
	}

	
	@Test     // added by jeremy williams
	public void testGetPhilCollinsAlbumSize() throws NoSuchFieldException, SecurityException {
		 PhilCollins philCollins = new PhilCollins();
		 ArrayList<Song> philCollinsTracks = new ArrayList<Song>();
		 philCollinsTracks = philCollins.getPhilCollinsSongs();
		 assertEquals(3, philCollinsTracks.size());
	}
	
	@Test     // added by jeremy williams
	public void testGetTheWeekndAlbumSize() throws NoSuchFieldException, SecurityException {
		 TheWeeknd theWeeknd = new TheWeeknd();
		 ArrayList<Song> theWeekndTracks = new ArrayList<Song>();
		 theWeekndTracks = theWeeknd.getTheWeekndSongs();
		 assertEquals(3, theWeekndTracks.size());
	}

	@Test	// added by Paul Schwartz 
	public void testDennisLloydAlbumSize() throws NoSuchFieldException, SecurityException {
		DennisLloyd dennisLloyd = new DennisLloyd();
		ArrayList<Song> dennisLloydTracks = new ArrayList<Song>();
		dennisLloydTracks = dennisLloyd.getDennisLloydSongs();
		assertEquals(3, dennisLloydTracks.size());  //Changed to 3 songs equals track size
		
	}
	@Test	// added by Paul Schwartz
	public void testPurityRingAlbumSize() throws NoSuchFieldException, SecurityException {
		PurityRing purityRing = new PurityRing();
		ArrayList<Song> purityRingTracks = new ArrayList<Song>();
		purityRingTracks = purityRing.getPurityRingsSongs();
		assertEquals(3, purityRingTracks.size());  // Change to 3 songs to equals track size
	}
	@Test
	public void testGetGunsNRosesAlbumSize() throws NoSuchFieldException, SecurityException {
		 GunsNRoses gunsNRoses = new GunsNRoses();
		 ArrayList<Song> gunsNRosesTracks = new ArrayList<Song>();
		 gunsNRosesTracks = gunsNRoses.getGunsNRosesSongs();
		 assertEquals(3, gunsNRosesTracks.size());
	}
	@Test
	public void testGetLedZeppelinAlbumSize() throws NoSuchFieldException, SecurityException {
		 LedZeppelin ledZeppelin = new LedZeppelin();
		 ArrayList<Song> ledZeppelinTracks = new ArrayList<Song>();
		 ledZeppelinTracks = ledZeppelin.getLedZeppelinSongs();
		 assertEquals(3, ledZeppelinTracks.size());
	}
	
	@Test     // added by Raymond Prioleau
	public void testTheIsleyBrothersAlbumSize() throws NoSuchFieldException, SecurityException {
		 TheIsleyBrothers isleyBrothers = new TheIsleyBrothers();
		 ArrayList<Song> isleyBrothersTracks = new ArrayList<Song>();
		 isleyBrothersTracks = isleyBrothers.getIsleyBrothersSongs();
		 assertEquals(4, isleyBrothersTracks.size());
	}
	
	@Test     // added by Raymond Prioleau
	public void testKoolAndTheGangAlbumSize() throws NoSuchFieldException, SecurityException {
		KoolAndTheGang koolAndTheGang = new KoolAndTheGang();
		 ArrayList<Song> koolAndTheGangTracks = new ArrayList<Song>();
		 koolAndTheGangTracks = koolAndTheGang.getKoolAndTheGangSongs();
		 assertEquals(2, koolAndTheGangTracks.size());
	}
}
