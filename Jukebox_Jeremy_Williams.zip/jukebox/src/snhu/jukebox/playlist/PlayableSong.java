package snhu.jukebox.playlist;

public abstract class PlayableSong {
	    String title;
	    String artist;
	    
	    abstract void play();
	   
}
