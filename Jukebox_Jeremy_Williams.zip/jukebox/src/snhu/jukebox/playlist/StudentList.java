package snhu.jukebox.playlist;

import snhu.student.playlists.*;

import java.util.ArrayList;
import java.util.List;

public class StudentList {

	public StudentList(){
	}

	public List<String> getStudentsNames() {
		ArrayList<String> studentNames = new ArrayList<String>();
		
		String StudentName1 = "TestStudent1Name";
		studentNames.add(StudentName1);
		
		String StudentName2 = "TestStudent2Name";
		studentNames.add(StudentName2);
		
		String GlennFox = "Glenn Fox";
		studentNames.add(GlennFox);
		
		String PhilipEnkema = "Philip Enkema";  // added instructor as student
		studentNames.add(PhilipEnkema);
		
		String RaymondPrioleau = "Raymond Prioleau";  // added myself as student
		studentNames.add(RaymondPrioleau);
		
		String NicholasEls = "Nicholas Els";	// added self to list
		studentNames.add(NicholasEls);
		

		String ErikTomchek = "Erik Tomchek";  // added myself as student
		studentNames.add(ErikTomchek);
		

		String JeremyWilliams = "Jeremy Williams";  // added myself as student
		studentNames.add(JeremyWilliams);


		String MarkEllis = "Mark Ellis";  // added student as student by Mark Ellis 2021-09-30
		studentNames.add(MarkEllis);

		String PaulSchwartz = "Paul Schwartz"; // added myself Paul Schwartz to list
		studentNames.add(PaulSchwartz);
		
		String XhefriToro = "Xhefri Toro"; // added Xhefri Toro to list
		studentNames.add(XhefriToro);
		
		String KennethPosley = "Kenneth Posley"; // added Kenneth Posley to the student list
		studentNames.add(KennethPosley);

		
		return studentNames;
	}

	public Student GetStudentProfile(String student){
		Student emptyStudent = null;
	
		switch(student) {
		   case "TestStudent1_Playlist":
			   TestStudent1_Playlist testStudent1Playlist = new TestStudent1_Playlist();
			   Student TestStudent1 = new Student("TestStudent1", testStudent1Playlist.StudentPlaylist());
			   return TestStudent1;
			   
		   case "TestStudent2_Playlist":
			   TestStudent2_Playlist testStudent2Playlist = new TestStudent2_Playlist();
			   Student TestStudent2 = new Student("TestStudent2", testStudent2Playlist.StudentPlaylist());
			   return TestStudent2;
			   
			   
		   //Module 6 Code Assignment - Add your own case statement for your profile. Use the above case statements as a template.
			   
		   case "PhilipEnkema_Playlist":
			   PhilipEnkema_Playlist PhilipEnkema_Playlist = new PhilipEnkema_Playlist();
			   Student PhilipEnkema = new Student("Philip Enkema", PhilipEnkema_Playlist.StudentPlaylist());
			   return PhilipEnkema;
			   
		   case "ErikTomchek_Playlist":
			   ErikTomchek_Playlist ErikTomchek_Playlist = new ErikTomchek_Playlist();
			   Student ErikTomchek = new Student("Erik Tomchek", ErikTomchek_Playlist.StudentPlaylist());
			   return ErikTomchek;
			   

		   case "JeremyWilliams_Playlist":
			   JeremyWilliams_Playlist JeremyWilliams_Playlist = new JeremyWilliams_Playlist();
			   Student JeremyWilliams = new Student("Jeremy Williams", JeremyWilliams_Playlist.StudentPlaylist());
			   return JeremyWilliams;
			  

		   case "GlennFox_Playlist":
			   GlennFox_Playlist GlennFox_Playlist = new GlennFox_Playlist();
			   Student GlennFox = new Student("Glenn Fox", GlennFox_Playlist.StudentPlaylist());
			   return GlennFox;
			   
		   case "XhefriToro_Playlist":
			   XhefriToro_Playlist xhefriToro_Playlist = new XhefriToro_Playlist();
			   Student xhefriToro = new Student("Xhefri Toro", xhefriToro_Playlist.StudentPlaylist());
			   return xhefriToro;
			   
			   
		   case "RaymondPrioleau_Playlist":
			   RaymondPrioleau_Playlist RaymondPrioleau_Playlist = new RaymondPrioleau_Playlist();
			   Student RaymondPrioleau = new Student("Raymond Prioleau", RaymondPrioleau_Playlist.StudentPlaylist());
			   return RaymondPrioleau;
			      

		}
		return emptyStudent;
	}
}
