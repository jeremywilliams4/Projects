package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class RadioHead {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public RadioHead() {
    }
    
    public ArrayList<Song> getRadioHeadSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                 		 
    	 Song track1 = new Song("Nude", "Radiohead");           		  
         Song track2 = new Song("Lucky", "Radiohead");      		  
         Song track3 = new Song("Fake Plastic Trees", "Radiohead");
         this.albumTracks.add(track1);                                         
         this.albumTracks.add(track2);                                         		  
         this.albumTracks.add(track3);												 
         return albumTracks;                                                    	  
         }

}
