package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class Rush {
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public Rush() {
    }
    
    public ArrayList<Song> getRushSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                 		  //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Tom Sawyer", "Rush");           					  //Added by g.fox
         this.albumTracks.add(track1);                                         		  //Add the first song to song list for Rush
         return albumTracks;                                                    	  //Return the songs for Rush in the form of an ArrayList
    }
}
