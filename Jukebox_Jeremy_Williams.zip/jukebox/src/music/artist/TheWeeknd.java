package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class TheWeeknd {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public TheWeeknd() {
    }
    
    public ArrayList<Song> getTheWeekndSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                 		  //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Blinding Lights", "TheWeeknd");           		          //Create a song
         Song track2 = new Song("Can't Feel My Face", "TheWeeknd");      		  //Create another song
         Song track3 = new Song("Starboy", "TheWeeknd");                      //Create another song	
         this.albumTracks.add(track1);                                         		  //Add the first song to song list for Phil Collins
         this.albumTracks.add(track2);                                         		  //Add the second song to song list for the Phil Collins 
         this.albumTracks.add(track3);												  //Add the third song to song list for Phil Collins
         return albumTracks;                                                    	  //Return the songs for the Phil Collins in the form of an ArrayList
    }
}