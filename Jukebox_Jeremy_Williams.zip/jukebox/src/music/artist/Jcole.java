package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class Jcole {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public Jcole() {
    }
    
    public ArrayList<Song> getJcoleSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                 		
    	 Song track1 = new Song("Amari", "Jcole");           		  
         Song track2 = new Song("my.life", "JCole & 21 Savage & Morray");      		  
         Song track3 = new Song("pride.is.the.devil", "JCole & Lil Baby"); 	
         this.albumTracks.add(track1);                                         		  
         this.albumTracks.add(track2);                                         		   
         this.albumTracks.add(track3);												  
         return albumTracks;                                                    	   
    	}
}
    