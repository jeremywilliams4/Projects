package music.artist;

import java.util.ArrayList;

import snhu.jukebox.playlist.Song;

public class GunsNRoses {

	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public GunsNRoses() {
    }
    
    public ArrayList<Song> getGunsNRosesSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                           //Instantiate the album so we can populate it below
    	 Song track1 = new Song("November Rain", "GunsNRoses");         				//Create a song
         Song track2 = new Song("Dont Cry", "GunsNRoses");        //Create another song
         Song track3 = new Song("Paradise City", "GunsNRoses");       //Create a third song
         this.albumTracks.add(track1);                                  //Add the first song to song list
         this.albumTracks.add(track2);                                  //Add the second song to song list
         this.albumTracks.add(track3);                                  //Add the third song to song list
         return albumTracks;                                            //Return the songs for GunsNRoses in the form of an ArrayList
    }
}