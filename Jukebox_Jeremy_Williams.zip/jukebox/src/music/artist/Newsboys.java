package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

// modified and added by Mark Ellis 2021-09-30

public class Newsboys {
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public Newsboys() {
    }
    
    public ArrayList<Song> getNewsboysSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                 		  //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Escape", "The Newsboys");           		          //Create a song
         Song track2 = new Song("Restart", "The Newsboys");      		              //Create another song
         Song track3 = new Song("That's How You Change the World", "The Newsboys");   //Create another song	
         this.albumTracks.add(track1);                                         		  //Add the first song to song list for the Newsboys
         this.albumTracks.add(track2);                                         		  //Add the second song to song list for the Newsboys 
         this.albumTracks.add(track3);												  //Add the third song to song list for the Newsboys
         return albumTracks;                                                    	  //Return the songs for the Newsboys in the form of an ArrayList
    }
}
