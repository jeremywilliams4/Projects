//  Added for Module 5 requirements P.Schwartz 10/02/21
package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class PurityRing {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public PurityRing() {
    }
    
    public ArrayList<Song> getPurityRingsSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                 		  //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Begin Again", "Purity Ring");           		  //Create a song
         Song track2 = new Song("Bodyache", "Purity Ring");      		  //Create another song
         Song track3 = new Song("Sea Castle", "Purity Ring"); // Create Another Song P.schwartz
         this.albumTracks.add(track1);                                         		  //Add the first song to song list for the Purity Ring
         this.albumTracks.add(track2);                                         		  //Add the second song to song list for the Purity Ring
         this.albumTracks.add(track3);												  //Added by P.schwartz
         return albumTracks;                                                    	  //Return the songs for the Purity Ring in the form of an ArrayList
    }
}