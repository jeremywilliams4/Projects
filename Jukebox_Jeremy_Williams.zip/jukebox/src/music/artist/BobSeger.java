//Added by E. Tomchek on 09/25/21

package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class BobSeger {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public BobSeger() {
    }
    
    public ArrayList<Song> getBobSegerSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Turn the Page", "Bob Seger");                  //Create a song
         Song track2 = new Song("Old Time Rock & Roll", "Bob Seger");           //Create another song
         Song track3 = new Song("Like a Rock", "Bob Seger");                    //Create another song
         Song track4 = new Song("Still the Same", "Bob Seger");                 //Create another song
         this.albumTracks.add(track1);                                          //Add the first song to song list for Bob Seger
         this.albumTracks.add(track2);                                          //Add the second song to song list for Bob Seger 
         this.albumTracks.add(track3);                                          //Add the Third song to song list for Bob Seger
         this.albumTracks.add(track4);                                          //Add the Fourth song to song list for Bob Seger

         return albumTracks;                                                    //Return the songs for Bob Seger in the form of an ArrayList
    }
}
