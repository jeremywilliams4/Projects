package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class TheIsleyBrothers {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public TheIsleyBrothers() {
    }
    
    public ArrayList<Song> getIsleyBrothersSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Contagious", "The Isley Brothers");            //Create a song
         Song track2 = new Song("Shout", "The Isley Brothers");                 //Create another song
         Song track3 = new Song("Testify", "The Isley Brothers");               //Create another song
         Song track4 = new Song("For the Love of You", "The Isley Brothers");   //added by jeremy williams
         this.albumTracks.add(track1);                                          //Add the first song to song list for The Isley Brothers
         this.albumTracks.add(track2);                                          //Add the second song to song list for  The Isley Brothers
         this.albumTracks.add(track3);                                          //Add the third song to song list for  The Isley Brothers
         this.albumTracks.add(track4);                                          //added by jeremy williams
         return albumTracks;                                                    //Return the songs for  The Isley Brothers in the form of an ArrayList  
    }
}
