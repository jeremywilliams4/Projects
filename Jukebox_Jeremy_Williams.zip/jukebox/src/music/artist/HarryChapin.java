//Added by E. Tomchek on 09/25/21

package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class HarryChapin {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public HarryChapin() {
    }
    
    public ArrayList<Song> getHarryChapinSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Cat's in the Cradle", "Harry Chapin");         //Create a song
         this.albumTracks.add(track1);                                          //Add the first song to song list for Harry Chapin
         return albumTracks;                                                    //Return the songs for Harry Chapin in the form of an ArrayList
    }
}
