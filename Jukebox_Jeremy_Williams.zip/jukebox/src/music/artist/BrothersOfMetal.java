package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class BrothersOfMetal {	// added by nicholas_els
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public BrothersOfMetal() {
    }
    
    public ArrayList<Song> getBrothersOfMetalSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                 		  //Instantiate the album so we can populate it below
    	 Song track1 = new Song("The Mead Song", "Brothers Of Metal");           	  //Create a song
         Song track2 = new Song("Kaunaz Dagaz", "Brothers Of Metal");      		 	  //Create another song
         this.albumTracks.add(track1);                                         		  //Add the first song to song list for Brothers Of Metal
         this.albumTracks.add(track2);                                         		  //Add the second song to song list for Brothers Of Metal
         return albumTracks;                                                    	  //Return the songs for Brothers Of Metal in the form of an ArrayList
    }
}