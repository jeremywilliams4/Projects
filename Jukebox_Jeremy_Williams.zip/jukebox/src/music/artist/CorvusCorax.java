package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class CorvusCorax {	// added by nicholas_els
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public CorvusCorax() {
    }
    
    public ArrayList<Song> getCorvusCoraxSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                 		  //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Gjallarhorni", "Corvus Corax");           	 		  //Create a song
         Song track2 = new Song("Sauf noch ein", "Corvus Corax");      		 		  //Create another song
         Song track3 = new Song("Havfru", "Corvus Corax"); 					 		  //Create a third song	
         this.albumTracks.add(track1);                                         		  //Add the first song to song list for Corvus Corax
         this.albumTracks.add(track2);                                         		  //Add the second song to song list for Corvus Corax 
         this.albumTracks.add(track3);												  //Add the third song to song list for Corvus Corax
         return albumTracks;                                                    	  //Return the songs for Corvus Corax in the form of an ArrayList
    }
}