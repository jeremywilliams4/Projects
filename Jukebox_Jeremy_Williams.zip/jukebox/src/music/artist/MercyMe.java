package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

//modified and added by Mark Ellis 2021-09-30

public class MercyMe {
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public MercyMe() {
    }
    
    public ArrayList<Song> getMercyMeSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                 		  //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Flawless", "MercyMe");           		              //Create a song
         Song track2 = new Song("Happy Dance", "MercyMe");      		              //Create another song
         Song track3 = new Song("Shake", "MercyMe");                                  //Create another song	
         this.albumTracks.add(track1);                                         		  //Add the first song to song list for the MercyMe
         this.albumTracks.add(track2);                                         		  //Add the second song to song list for the MercyMe 
         this.albumTracks.add(track3);												  //Add the third song to song list for the MercyMe 
         return albumTracks;                                                    	  //Return the songs for the MercyMe in the form of an ArrayList
    }
}
