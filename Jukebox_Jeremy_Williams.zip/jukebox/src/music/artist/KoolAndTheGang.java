package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class KoolAndTheGang {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public KoolAndTheGang() {
    }
    
    public ArrayList<Song> getKoolAndTheGangSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Celebration", "Kool & The Gang");             //Create a song
         Song track2 = new Song("Get Down On It", "Kool & The Gang");         //Create another song
         this.albumTracks.add(track1);                                          //Add the first song to song list for Kool & The Gang
         this.albumTracks.add(track2);                                          //Add the second song to song list for  Kool & The Gang 
         return albumTracks;                                                    //Return the songs for  Kool & The Gang in the form of an ArrayList  
    }
}
